package currencyprice.eoinahern.ie.currency_price.ui



class CurrencyViewModel {


	fun currencyList() {

	}


	//initial call
	fun initGetCurrency() {

	}

	//update while activity open
	fun updateCurrencyData() {


	}



	fun unsubscribe() {

	}
}