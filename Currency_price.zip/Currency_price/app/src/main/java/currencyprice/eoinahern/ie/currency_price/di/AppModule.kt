package currencyprice.eoinahern.ie.currency_price.di

class AppModule {




}