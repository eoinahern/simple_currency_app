package currencyprice.eoinahern.ie.currency_price.data


data class CurrencyInfo(
		val name: String,
		val cost: Float)