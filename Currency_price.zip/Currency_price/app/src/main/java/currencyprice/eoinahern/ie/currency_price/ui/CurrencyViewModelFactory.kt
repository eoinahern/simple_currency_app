package currencyprice.eoinahern.ie.currency_price.ui

import androidx.lifecycle.ViewModel


class CurrencyViewModelFactory : ViewModel() {

}