package currencyprice.eoinahern.ie.currency_price.data

interface currencyApi{



}