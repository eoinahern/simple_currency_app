package currencyprice.eoinahern.ie.currency_price.ui

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import currencyprice.eoinahern.ie.currency_price.R

class CurrencyActivity : AppCompatActivity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_currency)
		initViewModel()
	}

	override fun onResume() {
		super.onResume()
	}


	private fun initViewModel() {

	}


	private fun showLoading() {

	}

	private fun hideLoading() {

	}

	override fun onPause() {
		super.onPause()
	}

	override fun onDestroy() {
		super.onDestroy()
	}
}
